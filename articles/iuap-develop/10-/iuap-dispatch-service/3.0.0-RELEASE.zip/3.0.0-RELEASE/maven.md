 <dependency>
  <groupId>com.yonyou.iuap</groupId>
  <artifactId>iuap-saas-dispatch-service</artifactId>
  <version>3.0.0-RELEASE</version>
  <type>war</type>
 </dependency>
